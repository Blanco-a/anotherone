<?php
    include_once("../db.php");
?>
<!DOCTYPE html>
<html lang="en">
<body>
    <?php
        include_once("../nav.php");
    ?>
    <div class="container mt-5">
        <div class="row">
            <div class="col-sm-12">
                <a href="spelertcreate.php" class="btn btn-success">Toevoegen</a>
                <table class="table table-striped table-bordered mt-2">
                    <thead>
                    <tr>
                        <td>Medewerkers ID</td>
                        <td>Tijd</td>
                    </tr>
                    </thead>
                    <tbody>
                    <?php
                        $conn = new PDO("mysql:host=$servername;dbname=$dbname", $staffID, $time);
                        $sql = 'SELECT * FROM intakes ORDER BY staffID DESC';
                        
                        foreach ($conn->query($sql) as $row) {
                            echo '<tr>';
                            echo '<td>'. $row['staffID'] . '</td>';
                            echo '<td>'. $row['time'] . '</td>';
                            echo '<a class="btn btn-success" href="spelerupdate.php?spelersid='.$row['staffID'].'">Wijzigen</a>';
                            echo ' ';
                            echo '<a class="btn btn-danger" href="spelerdelete.php?spelersid='.$row['StaffID'].'">Verwijderen</a>';
                            echo '</td>';
                            echo '</tr>';
                        }
                        $conn = null;
                    ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</body>
</html>