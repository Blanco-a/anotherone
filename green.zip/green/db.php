<?php
$servername = 'localhost';
$dbname = 'green';
$username = 'root';
$password = '';

try {
	$conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
	$dbConn = new PDO("mysql:host={$servername};dbname={$dbname}", $username, $password);
	$dbConn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); 
} catch(PDOException $e) {
	echo $e->getMessage();
}
?>